import { useSelector, useDispatch } from "react-redux";
import { toggleFavorite } from "./recepiesSlice";
import "./RecipeList.css";

const FavoriteRecipes = () => {
  const dispatch = useDispatch();
  const recipes = useSelector((state) => state.recipes.recipeList);
  const favorites = recipes.filter((r) => r.isFavorite);

  return (
    <div className="recipe-container">
      <h2 className="recipe-heading">❤️ Favorite Recipes</h2>
      {favorites.length === 0 ? (
        <p className="no-result">You haven't added any favorites yet.</p>
      ) : (
        favorites.map((recipe) => (
          <div key={recipe.id} className="recipe-card">
            <h3>
              {recipe.title}
              <button
                onClick={() => {
                  dispatch(toggleFavorite(recipe.id));
                  alert(
                    recipe.isFavorite
                      ? `"${recipe.title}" removed from favorites.`
                      : `"${recipe.title}" added to favorites.`
                  );
                }}
                style={{
                  background: "none",
                  border: "none",
                  fontSize: "22px",
                  cursor: "pointer",
                  float: "right",
                }}
                title={
                  recipe.isFavorite
                    ? "Remove from favorites"
                    : "Add to favorites"
                }
              >
                {recipe.isFavorite ? "❤️" : "🤍"}
              </button>
            </h3>
            <img src={recipe.imageUrl} alt={recipe.title} />
            <p>
              <strong>🕒 Prep Time:</strong> {recipe.prepTime} mins
            </p>
            <p>
              <strong>📝 Ingredients:</strong>
              <br />
              {recipe.ingredients}
            </p>
            <p>
              <strong>👨‍🍳 Instructions:</strong>
              <br />
              {recipe.instructions}
            </p>
          </div>
        ))
      )}
    </div>
  );
};

export default FavoriteRecipes;
