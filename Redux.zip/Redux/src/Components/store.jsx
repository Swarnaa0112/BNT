
// import { configureStore } from '@reduxjs/toolkit';
// import recipesReducer from '../Components/recepiesSlice';

// export const store = configureStore({
//   reducer: {
//     recipes: recipesReducer,
//   },
// });
// export default store
import { configureStore } from "@reduxjs/toolkit";
import recipesReducer from "./recepiesSlice";

const store = configureStore({
  reducer: {
    recipes: recipesReducer,
  },
});

export default store;
