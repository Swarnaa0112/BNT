import React from "react";
import { useSelector, useDispatch } from "react-redux";
import { setSearchTerm, toggleFavorite, deleteRecipe } from "./recepiesSlice";
import "./RecipeList.css";

const RecepieList = () => {
  const dispatch = useDispatch();
  const recipes = useSelector((state) => state.recipes.recipeList);
  const searchTerm = useSelector((state) => state.recipes.searchTerm);

  const handleSearch = (e) => {
    dispatch(setSearchTerm(e.target.value));
  };

  const filteredRecipes = recipes.filter((recipe) =>
    recipe.title.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="recipe-container">
      <h2 className="recipe-heading">📖 All Recipes</h2>
      <input
        type="text"
        placeholder="Search recipes..."
        value={searchTerm}
        onChange={handleSearch}
        className="search-bar"
      />

      {filteredRecipes.length === 0 ? (
        <p className="no-result">No recipes found.</p>
      ) : (
        filteredRecipes.map((recipe) => (
          <div key={recipe.id} className="recipe-card">
            <h3>
              {recipe.title}
              <button
                onClick={() => {
                  dispatch(toggleFavorite(recipe.id));
                  alert(
                    recipe.isFavorite
                      ? `"${recipe.title}" removed from favorites.`
                      : `"${recipe.title}" added to favorites.`
                  );
                }}
                style={{
                  background: "none",
                  border: "none",
                  fontSize: "22px",
                  cursor: "pointer",
                  float: "right",
                }}
                title={
                  recipe.isFavorite
                    ? "Remove from favorites"
                    : "Add to favorites"
                }
              >
                {recipe.isFavorite ? "❤️" : "🤍"}
              </button>
            </h3>
            <img src={recipe.imageUrl} alt={recipe.title} />
            <p>
              <strong>🕒 Prep Time:</strong> {recipe.prepTime} mins
            </p>
            <p>
              <strong>📝 Ingredients:</strong>
              <br />
              {recipe.ingredients}
            </p>
            <p>
              <strong>👨‍🍳 Instructions:</strong>
              <br />
              {recipe.instructions}
            </p>
            <button
              onClick={() => {
                const confirmDelete = window.confirm(
                  "Are you sure you want to delete this recipe?"
                );
                if (confirmDelete) {
                  dispatch(deleteRecipe(recipe.id));
                }
              }}
              style={{
                background: "#e74c3c",
                color: "white",
                border: "none",
                borderRadius: "5px",
                padding: "5px 10px",
                marginTop: "10px",
                cursor: "pointer",
              }}
            >
              Delete
            </button>
          </div>
        ))
      )}
    </div>
  );
};

export default RecepieList;
