import React, { useState } from "react";
import { useDispatch } from "react-redux";
import { addRecipe } from "../Components/recepiesSlice";

const AddRecipe = () => {
  const dispatch = useDispatch();
  const [title, setTitle] = useState('');
  const [ingredients, setIngredients] = useState('');
  const [instructions, setInstructions] = useState('');
  const [prepTime, setPrepTime] = useState('');
  const [imageUrl, setImageUrl] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();

    const newRecipe = {
      id: Date.now(),
      title,
      ingredients,
      instructions,
      prepTime,
      imageUrl,
    };

    dispatch(addRecipe(newRecipe));
    alert("Recipe Added!");
    
    // Reset form
    setTitle('');
    setIngredients('');
    setInstructions('');
    setPrepTime('');
    setImageUrl('');
  };

  return (
    <div style={{ maxWidth: 500, margin: 'auto', padding: 20 }}>
      <h2 style={{textAlign:"center"}}>Add New Recipe</h2>
      <form onSubmit={handleSubmit}>
        <input style={{width:"500px",height:"30px"}}
          type="text"
          placeholder="Recipe Title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          required
        /><br /><br />
        <input style={{width:"500px",height:"30px"}}
          type="text"
          placeholder="Image URL"
          value={imageUrl}
          onChange={(e) => setImageUrl(e.target.value)}
          required
        /><br /><br />
        <textarea style={{width:"500px",height:"30px"}}
          placeholder="Ingredients"
          value={ingredients}
          onChange={(e) => setIngredients(e.target.value)}
          required
        /><br /><br />
        <textarea style={{width:"500px",height:"30px"}}
          placeholder="Instructions"
          value={instructions}
          onChange={(e) => setInstructions(e.target.value)}
          required
        /><br /><br />
        <input style={{width:"500px",height:"30px"}}
          type="number"
          placeholder="Prep Time (mins)"
          value={prepTime}
          onChange={(e) => setPrepTime(e.target.value)}
          required
        /><br /><br />
       <button type="submit" style={{height:"30px",width:"300px",textAlign:"center",marginLeft:"85px",borderRadius:"10px",backgroundColor:"#c2e5c24f",borderColor:"white"}}><b>Add Recipe</b></button>
      </form>
    </div>
  );
};

export default AddRecipe;
