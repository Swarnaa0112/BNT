import { createSlice } from "@reduxjs/toolkit";

const recipesSlice = createSlice({
  name: "recipes",
  initialState: {
    recipeList: [],
    searchTerm: "", 
  },
  reducers: {
    addRecipe: (state, action) => {
      state.recipeList.push(action.payload);
    },
    setSearchTerm: (state, action) => {
      state.searchTerm = action.payload;
    },
    toggleFavorite: (state, action) => {
      const recipe = state.recipeList.find((r) => r.id === action.payload);
      if (recipe) {
        recipe.isFavorite = !recipe.isFavorite;
      }
    },
    deleteRecipe: (state, action) => {
      state.recipeList = state.recipeList.filter(
        (recipe) => recipe.id !== action.payload
      );
    },
  },
});

export const { addRecipe, setSearchTerm, toggleFavorite ,deleteRecipe} =
  recipesSlice.actions;
export default recipesSlice.reducer;
