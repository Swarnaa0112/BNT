import React from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import AddRecipe from "../src/Components/AddRecepie";
import RecipeList from "../src/Components/RecepieList";
import FavoriteRecipes from "../src/Components/FavoriteRecipes"; 

function App() {
  return (
    <Router>
      <div className="header-section">
        <h1 className="header-title">🍲 My Recipe Book</h1>
      </div>

      {/* Simple Navigation */}
      <nav style={{ textAlign: "center", marginBottom: "20px" }}>
        <Link to="/" style={{ margin: "0 15px" }}>All Recipes</Link>
        <Link to="/add" style={{ margin: "0 15px" }}>Add Recipe</Link>
        <Link to="/favorites" style={{ margin: "0 15px" }}>Favorites</Link>
      </nav>

      {/* Routes */}
      <Routes>
        <Route path="/" element={<RecipeList />} />
        <Route path="/add" element={<AddRecipe />} />
        <Route path="/favorites" element={<FavoriteRecipes />} />
      </Routes>
    </Router>
  );
}

export default App;
